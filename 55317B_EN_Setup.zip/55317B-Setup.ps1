# ============================================================================== 
# Courseware Studio Single-Script Setup: 55317B
# ============================================================================== 
#Requires -RunAsAdministrator

[CmdletBinding()]
param(
  [string]$DeployRoot = 'C:\55317BDeploy',
  [string]$VMName = '55317B',
  [string]$SwitchName = 'Default Switch',
  [switch]$SkipVmCreation,
  [switch]$SkipGuestAutomation,
  [switch]$FailOnMissing
)

$ErrorActionPreference = 'Stop'

$CourseNumber = '55317B'
$CourseTitle = 'Querying Microsoft SQL Server 2025'
$EnvironmentType = 'hyperv_vm'
$OsTarget = 'windows'
$IsHyperV = $true
$IsDocker = $false
$LooksWindows = $true
$LooksLinux = $false
$AdministratorPassword = 'Pa$$w0rdPa$$w0rd'
$StudentPassword = 'Pa$$w0rd'
$HyperVRoot = Join-Path $DeployRoot 'HyperV'
$LogRoot = Join-Path $DeployRoot 'Logs'
$VmRoot = Join-Path $HyperVRoot 'VirtualMachines'
$VhdRoot = Join-Path $HyperVRoot 'VirtualHardDisks'
$VhdPath = Join-Path $VhdRoot ($VMName + '.vhdx')
$PayloadVhdPath = Join-Path $VhdRoot ('SetupPayload_' + $VMName + '.vhdx')

$FolderPlan = @(
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'WindowsServer2025'); Purpose = 'Guest operating system installation media' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'SQLSERVER2025'); Purpose = 'SQL Server setup media' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'SSMS22'); Purpose = 'SQL Server Management Studio installer' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'VSCode'); Purpose = 'Visual Studio Code installer' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'PowerShell7'); Purpose = 'PowerShell 7 installer/package' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'NodeJS'); Purpose = 'Node.js installer/package' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'Git'); Purpose = 'Git installer/package' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'Docker'); Purpose = 'Docker installer/package or project resources' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'SampleDatabases'); Purpose = 'Sample database backups' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'CourseFiles'); Purpose = 'Course class files and lab resources' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'Logs'); Purpose = 'Setup and validation logs' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'HyperV\VirtualMachines'); Purpose = 'Hyper-V VM configuration files' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'HyperV\VirtualHardDisks'); Purpose = 'Hyper-V VHDX files' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'HyperV\Checkpoints'); Purpose = 'Hyper-V checkpoints' },
  [pscustomobject]@{ Path = (Join-Path $DeployRoot 'HyperV\Exports'); Purpose = 'Hyper-V exports' }
)

$ResourcePlan = @(
  [pscustomobject]@{ Name = 'windows ISO'; Folder = (Join-Path $DeployRoot 'WindowsServer2025'); ExpectedFiles = @('WindowsServer2025.iso', '*.iso'); Required = $true; Kind = 'file'; Notes = 'Licensed Windows installation ISO supplied by the client.' },
  [pscustomobject]@{ Name = 'SQL Server setup media'; Folder = (Join-Path $DeployRoot 'SQLSERVER2025'); ExpectedFiles = @('setup.exe'); Required = $true; Kind = 'folderWithExpectedFile'; Notes = 'Extract SQL Server media so setup.exe is directly available in this folder. SQL Server ISO-only folders are not accepted by the single-script install path.' },
  [pscustomobject]@{ Name = 'SSMS 22 installer'; Folder = (Join-Path $DeployRoot 'SSMS22'); ExpectedFiles = @('vs_SSMS.exe', 'SSMS-Setup-ENU.exe', '*SSMS*.exe'); Required = $true; Kind = 'file'; Notes = 'SSMS 22 currently uses the vs_SSMS.exe Visual Studio Installer bootstrapper.' },
  [pscustomobject]@{ Name = 'Visual Studio Code installer'; Folder = (Join-Path $DeployRoot 'VSCode'); ExpectedFiles = @('VSCodeSetup-x64.exe', 'VSCodeUserSetup-x64.exe', '*VSCode*Setup*x64*.exe', '*Code*Setup*x64*.exe'); Required = $true; Kind = 'file'; Notes = 'Use the current x64 Windows installer for Windows-based labs.' },
  [pscustomobject]@{ Name = 'PowerShell 7 installer'; Folder = (Join-Path $DeployRoot 'PowerShell7'); ExpectedFiles = @('PowerShell-*.msi', '*.msi'); Required = $true; Kind = 'file'; Notes = 'Use official PowerShell 7 installer media or package source documentation.' },
  [pscustomobject]@{ Name = 'Node.js installer'; Folder = (Join-Path $DeployRoot 'NodeJS'); ExpectedFiles = @('node-*.msi', '*.msi'); Required = $true; Kind = 'file'; Notes = 'Use official Node.js LTS installer media.' },
  [pscustomobject]@{ Name = 'Git installer'; Folder = (Join-Path $DeployRoot 'Git'); ExpectedFiles = @('Git-*.exe', '*.exe'); Required = $false; Kind = 'file'; Notes = 'Required only when course labs use Git locally.' },
  [pscustomobject]@{ Name = 'AdventureWorks2025 backup'; Folder = (Join-Path $DeployRoot 'SampleDatabases'); ExpectedFiles = @('AdventureWorks2025.bak'); Required = $true; Kind = 'file'; Notes = 'Required for SQL Server courses that use AdventureWorks OLTP examples.' },
  [pscustomobject]@{ Name = 'AdventureWorksDW2025 backup'; Folder = (Join-Path $DeployRoot 'SampleDatabases'); ExpectedFiles = @('AdventureWorksDW2025.bak'); Required = $true; Kind = 'file'; Notes = 'Required for SQL Server courses that use AdventureWorks data warehouse examples.' },
  [pscustomobject]@{ Name = 'Course class files zip'; Folder = (Join-Path $DeployRoot 'CourseFiles'); ExpectedFiles = @('55317B_Classfiles.zip', '*.zip'); Required = $false; Kind = 'file'; Notes = 'Optional class files archive when the course includes downloadable lab resources.' }
)

function Write-Section {
  param([string]$Text)
  Write-Host ''
  Write-Host ('=' * 70) -ForegroundColor DarkGray
  Write-Host $Text -ForegroundColor Cyan
  Write-Host ('=' * 70) -ForegroundColor DarkGray
}

function Ensure-Folder {
  param([string]$Path)
  if ([string]::IsNullOrWhiteSpace($Path)) { return }
  if (-not (Test-Path -LiteralPath $Path)) { New-Item -ItemType Directory -Path $Path -Force | Out-Null }
}

function Find-ExpectedResource {
  param($Resource)
  if (-not (Test-Path -LiteralPath $Resource.Folder)) { return $null }
  foreach ($pattern in @($Resource.ExpectedFiles)) {
    $exact = Join-Path $Resource.Folder $pattern
    if ($pattern -notmatch '[\*\?]' -and (Test-Path -LiteralPath $exact)) { return (Get-Item -LiteralPath $exact) }
    $candidate = Get-ChildItem -LiteralPath $Resource.Folder -Filter $pattern -File -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($candidate) { return $candidate }
  }
  return $null
}

function Test-SetupResources {
  $results = foreach ($resource in $ResourcePlan) {
    $candidate = Find-ExpectedResource -Resource $resource
    $exists = $null -ne $candidate
    [pscustomobject]@{
      Status = if ($resource.Required -and $exists) { 'FOUND' } elseif ($resource.Required) { 'MISSING' } elseif ($exists) { 'OPTIONAL FOUND' } else { 'OPTIONAL MISSING' }
      Name = $resource.Name
      Required = [bool]$resource.Required
      Exists = [bool]$exists
      Folder = $resource.Folder
      FoundPath = if ($candidate) { $candidate.FullName } else { $null }
      ExpectedFiles = ($resource.ExpectedFiles -join ', ')
      Notes = $resource.Notes
    }
  }

  Ensure-Folder -Path $LogRoot
  $jsonPath = Join-Path $LogRoot 'setup-resource-validation.json'
  $mdPath = Join-Path $LogRoot 'setup-resource-validation.md'
  $results | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $jsonPath -Encoding UTF8

  $md = New-Object System.Collections.Generic.List[string]
  $md.Add('# Setup Resource Validation')
  $md.Add('')
  $md.Add("- Generated: $(Get-Date -Format s)")
  $md.Add("- Course: $CourseNumber")
  $md.Add("- Deployment root: $DeployRoot")
  $md.Add('')
  $md.Add('| Status | Resource | Required | Folder | Found path | Expected files | Notes |')
  $md.Add('|---|---|---:|---|---|---|---|')
  foreach ($item in $results) {
    $md.Add('| ' + $item.Status + ' | ' + $item.Name + ' | ' + $item.Required + ' | ' + $item.Folder + ' | ' + $item.FoundPath + ' | ' + $item.ExpectedFiles + ' | ' + $item.Notes + ' |')
  }
  $md | Set-Content -LiteralPath $mdPath -Encoding UTF8

  Write-Host ''
  Write-Host 'Setup resource checklist' -ForegroundColor Cyan
  foreach ($item in $results) {
    $color = if ($item.Status -eq 'FOUND' -or $item.Status -eq 'OPTIONAL FOUND') { 'Green' } elseif ($item.Status -eq 'MISSING') { 'Red' } else { 'DarkYellow' }
    Write-Host "[$($item.Status)] $($item.Name)" -ForegroundColor $color
    Write-Host "  Folder:   $($item.Folder)"
    Write-Host "  Expected: $($item.ExpectedFiles)"
    if ($item.FoundPath) { Write-Host "  Found:    $($item.FoundPath)" }
    if (-not $item.Exists -and $item.Required) { Write-Host "  Action:   Place the required resource in this folder." -ForegroundColor Yellow }
    Write-Host ''
  }
  Write-Host "Reports written:" -ForegroundColor Cyan
  Write-Host "  JSON:     $jsonPath"
  Write-Host "  Markdown: $mdPath"

  return @($results | Where-Object { $_.Required -and -not $_.Exists })
}

function Test-HyperVReady {
  if (-not $IsHyperV) { return }
  if (-not (Get-Command Get-VM -ErrorAction SilentlyContinue)) { throw 'Hyper-V PowerShell commands are not available. Install/enable Hyper-V and management tools.' }
  $vmms = Get-Service -Name vmms -ErrorAction SilentlyContinue
  if (-not $vmms -or $vmms.Status -ne 'Running') { throw 'Hyper-V Virtual Machine Management service is not running.' }
  Get-VMHost -ErrorAction Stop | Out-Null
}

function New-SetupPayloadVhd {
  if (-not $IsHyperV) { return }
  if (Test-Path -LiteralPath $PayloadVhdPath) {
    Write-Host 'Setup payload VHDX already exists. Skipping payload creation.' -ForegroundColor Yellow
    return
  }
  Write-Host 'Creating setup payload VHDX...' -ForegroundColor Cyan
  $payloadSizeBytes = [int64]50 * 1GB
  New-VHD -Path $PayloadVhdPath -Dynamic -SizeBytes $payloadSizeBytes | Out-Null
  $mounted = Mount-VHD -Path $PayloadVhdPath -PassThru
  try {
    $disk = $mounted | Get-Disk
    if ($disk.PartitionStyle -eq 'RAW') { Initialize-Disk -Number $disk.Number -PartitionStyle GPT | Out-Null }
    $partition = New-Partition -DiskNumber $disk.Number -UseMaximumSize -AssignDriveLetter
    Format-Volume -Partition $partition -FileSystem NTFS -NewFileSystemLabel 'SetupPayload' -Confirm:$false -Force | Out-Null
    $payloadDrive = "$($partition.DriveLetter):\"
    foreach ($folder in $FolderPlan) {
      if ($folder.Path -like "$DeployRoot\HyperV*") { continue }
      if ($folder.Path -like "$DeployRoot\Logs*") { continue }
      if (Test-Path -LiteralPath $folder.Path) {
        $dest = Join-Path $payloadDrive ((Split-Path -Path $folder.Path -Leaf))
        Copy-Item -Path $folder.Path -Destination $dest -Recurse -Force -ErrorAction SilentlyContinue
      }
    }
  }
  finally {
    Dismount-VHD -Path $PayloadVhdPath -ErrorAction SilentlyContinue
  }
}

function New-CourseHyperVVm {
  if (-not $IsHyperV -or $SkipVmCreation) { return }
  $existing = Get-VM -Name $VMName -ErrorAction SilentlyContinue
  if ($existing) {
    Write-Host "VM already exists: $VMName. Skipping VM creation." -ForegroundColor Yellow
    return
  }
  $osIsoPath = $null
  $osIsoResource = [pscustomobject]@{ Folder = 'C:\55317BDeploy\WindowsServer2025'; ExpectedFiles = @('WindowsServer2025.iso', '*.iso') }
  $osIsoCandidate = Find-ExpectedResource -Resource $osIsoResource
  if ($osIsoCandidate) { $osIsoPath = $osIsoCandidate.FullName }
  if (-not $osIsoPath) { throw 'Guest OS ISO was not found. Run resource validation and place the OS ISO before VM creation.' }
  Ensure-Folder -Path $VmRoot
  Ensure-Folder -Path $VhdRoot
  if (Test-Path -LiteralPath $VhdPath) { Remove-Item -LiteralPath $VhdPath -Force }
  Write-Host "Creating Hyper-V VM: $VMName" -ForegroundColor Cyan
  New-VM -Name $VMName -Path $VmRoot -Generation 2 -MemoryStartupBytes 8GB -SwitchName $SwitchName | Out-Null
  Set-VM -Name $VMName -ProcessorCount 4 -DynamicMemory -MemoryMinimumBytes 4GB -MemoryMaximumBytes 12GB | Out-Null
  New-VHD -Path $VhdPath -Dynamic -SizeBytes 120GB | Out-Null
  Add-VMHardDiskDrive -VMName $VMName -Path $VhdPath | Out-Null
  Add-VMDvdDrive -VMName $VMName -Path $osIsoPath | Out-Null
  if (Test-Path -LiteralPath $PayloadVhdPath) { Add-VMHardDiskDrive -VMName $VMName -Path $PayloadVhdPath | Out-Null }
  $dvdDrive = Get-VMDvdDrive -VMName $VMName
  $hardDisk = Get-VMHardDiskDrive -VMName $VMName | Select-Object -First 1
  Set-VMFirmware -VMName $VMName -BootOrder $dvdDrive, $hardDisk | Out-Null
  Enable-VMIntegrationService -VMName $VMName -Name "Guest Service Interface" -ErrorAction SilentlyContinue | Out-Null
  Start-VM -Name $VMName | Out-Null
}

function Invoke-WindowsGuestAutomation {
  if (-not $IsHyperV -or -not $LooksWindows -or $SkipGuestAutomation) { return }
  Write-Host ''
  Write-Host 'ACTION REQUIRED: install the guest OS if it is not already installed.' -ForegroundColor Yellow
  Write-Host 'When Windows is at the desktop, sign in as Administrator.'
  Write-Host 'Administrator password: Pa$$w0rdPa$$w0rd'
  Read-Host 'Press ENTER after the VM is at the Windows desktop' | Out-Null
  $guestCred = New-Object System.Management.Automation.PSCredential ('Administrator', (ConvertTo-SecureString $AdministratorPassword -AsPlainText -Force))
  Invoke-Command -VMName $VMName -Credential $guestCred -ScriptBlock {
    $ErrorActionPreference = 'Stop'
    $adminPassword = 'Pa$$w0rdPa$$w0rd'
    $studentPassword = 'Pa$$w0rd'
    Write-Host 'Configuring standard classroom accounts...'
    $accounts = @{ 'Administrator' = $adminPassword; 'Adminz' = $adminPassword; 'Student' = $studentPassword }
    foreach ($user in $accounts.Keys) {
      $secure = ConvertTo-SecureString $accounts[$user] -AsPlainText -Force
      if (Get-LocalUser -Name $user -ErrorAction SilentlyContinue) {
        Set-LocalUser -Name $user -Password $secure -PasswordNeverExpires $true
      } else {
        New-LocalUser -Name $user -Password $secure -FullName ($user + ' Account') -PasswordNeverExpires | Out-Null
      }
      Add-LocalGroupMember -Group 'Administrators' -Member $user -ErrorAction SilentlyContinue
    }
    Get-Disk | Where-Object IsOffline -eq $true | Set-Disk -IsOffline $false -ErrorAction SilentlyContinue
    $payloadVol = Get-Volume | Where-Object FileSystemLabel -eq 'SetupPayload' | Select-Object -First 1
    if ($payloadVol -and -not $payloadVol.DriveLetter) { Get-Partition -Volume $payloadVol | Set-Partition -AssignDriveLetter | Out-Null; $payloadVol = Get-Volume | Where-Object FileSystemLabel -eq 'SetupPayload' | Select-Object -First 1 }
    $payloadDrive = if ($payloadVol -and $payloadVol.DriveLetter) { "$($payloadVol.DriveLetter):\" } else { $null }
    if (-not (Test-Path 'C:\Classfiles')) { New-Item -ItemType Directory -Path 'C:\Classfiles' -Force | Out-Null }
    if (-not (Test-Path 'C:\Temp')) { New-Item -ItemType Directory -Path 'C:\Temp' -Force | Out-Null }
    if ($payloadDrive -and -not (Get-Service -Name 'MSSQLSERVER' -ErrorAction SilentlyContinue)) {
      $sqlSetup = Join-Path $payloadDrive 'SQLSERVER2025\setup.exe'
      if (Test-Path $sqlSetup) {
        Write-Host 'Installing SQL Server...'
        $iniPath = 'C:\Temp\SQLSERVER.ini'
        $iniLines = @(
          '[OPTIONS]'
          'ACTION="Install"'
          'FEATURES=SQLENGINE'
          'INSTANCENAME="MSSQLSERVER"'
          'INSTANCEID="MSSQLSERVER"'
          'SECURITYMODE="SQL"'
          'SQLSVCACCOUNT="NT AUTHORITY\NETWORK SERVICE"'
          'SQLSVCSTARTUPTYPE="Automatic"'
          'AGTSVCACCOUNT="NT AUTHORITY\NETWORK SERVICE"'
          'AGTSVCSTARTUPTYPE="Automatic"'
          ('SQLSYSADMINACCOUNTS="{0}\Administrator" "{0}\Adminz" "{0}\Student"' -f $env:COMPUTERNAME)
          'TCPENABLED="1"'
          'NPENABLED="0"'
          'UPDATEENABLED="False"'
          'QUIET="True"'
        )
        $iniLines | Set-Content -Path $iniPath -Encoding ASCII
        $proc = Start-Process -FilePath $sqlSetup -ArgumentList '/q', "/CONFIGURATIONFILE=$iniPath", '/SAPWD=Pa$$w0rd', '/IACCEPTSQLSERVERLICENSETERMS' -Wait -NoNewWindow -PassThru
        if ($proc.ExitCode -ne 0) { throw "SQL Server setup failed with exit code $($proc.ExitCode)" }
      }
    }
    if ($payloadDrive) {
      $ssms = Get-ChildItem -Path (Join-Path $payloadDrive 'SSMS22') -Filter 'vs_SSMS.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($ssms -and -not (Get-ChildItem -Path 'C:\Program Files*\Microsoft SQL Server Management Studio*' -Filter 'Ssms.exe' -Recurse -ErrorAction SilentlyContinue)) {
        Write-Host 'Installing SSMS...'
        Start-Process -FilePath $ssms.FullName -ArgumentList '--passive --includeRecommended --norestart --wait' -Wait -PassThru | Out-Null
      }
    }
    if ($payloadDrive -and -not (Test-Path 'C:\Program Files\Microsoft VS Code\Code.exe')) {
      $vscode = Get-ChildItem -Path (Join-Path $payloadDrive 'VSCode') -Filter '*code*setup*x64*.exe' -ErrorAction SilentlyContinue | Select-Object -First 1
      if ($vscode) {
        Write-Host 'Installing Visual Studio Code...'
        Start-Process -FilePath $vscode.FullName -ArgumentList '/VERYSILENT /SUPPRESSMSGBOXES /ALLUSERS /MERGETASKS=!runcode' -Wait -PassThru | Out-Null
      }
    }
    if ($payloadDrive -and (Get-Service -Name 'MSSQLSERVER' -ErrorAction SilentlyContinue)) {
      Start-Sleep -Seconds 10
      $conn = New-Object System.Data.SqlClient.SqlConnection('Server=localhost;Database=master;Integrated Security=True;')
      $conn.Open()
      foreach ($db in @('AdventureWorks2025','AdventureWorksDW2025')) {
        $cmd = $conn.CreateCommand()
        $cmd.CommandText = "SELECT database_id FROM sys.databases WHERE name = '$db'"
        $exists = $cmd.ExecuteScalar()
        if (-not $exists) {
          $bak = Join-Path (Join-Path $payloadDrive 'SampleDatabases') ($db + '.bak')
          if (Test-Path $bak) {
            Write-Host "Restoring $db..."
            $cmd.CommandTimeout = 0
            $cmd.CommandText = "RESTORE DATABASE [$db] FROM DISK = N'$bak' WITH REPLACE, RECOVERY;"
            $cmd.ExecuteNonQuery() | Out-Null
          }
        }
      }
      $conn.Close()
    }
  }
}

Write-Section "Phase 1: Create deployment folders"
Ensure-Folder -Path $DeployRoot
Ensure-Folder -Path $LogRoot
foreach ($folder in $FolderPlan) { Ensure-Folder -Path $folder.Path; Write-Host "OK  $($folder.Path)" }

Write-Section "Phase 2: Validate setup resources"
$missing = @(Test-SetupResources)
if ($missing.Count -gt 0) {
  Write-Warning "Missing $($missing.Count) required setup resource(s). Place the missing files and run this script again."
  $global:LASTEXITCODE = 1
  if ($FailOnMissing) { throw "Missing required setup resources." }
  return
}

if ($IsDocker) {
  Write-Section "Docker target validation"
  if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { throw "Docker was not found. Install Docker before continuing." }
  docker version | Out-Host
}

if ($IsHyperV) {
  Write-Section "Phase 3: Validate Hyper-V"
  Test-HyperVReady
  Write-Section "Phase 4: Create setup payload"
  New-SetupPayloadVhd
  Write-Section "Phase 5: Create or validate VM"
  New-CourseHyperVVm
  Write-Section "Phase 6: Guest automation"
  Invoke-WindowsGuestAutomation
}

Write-Section "Setup complete"
Write-Host "Course setup workflow completed for $CourseNumber." -ForegroundColor Green
Write-Host "Review logs in $LogRoot."
$global:LASTEXITCODE = 0
