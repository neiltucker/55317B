# 55317B Local Setup

This setup package prepares a local lab environment for **Querying Microsoft SQL Server 2025**.

The package uses a single setup script:

```text
55317B-Setup.ps1
```

Place the script and this README directly in the deployment root:

```text
C:\55317BDeploy\
  55317B-Setup.ps1
  README.md
```

## Before running the script

Create the deployment root and media folders, then download or copy the required setup files into the correct locations.

### Deployment root

```powershell
New-Item -ItemType Directory -Path C:\55317BDeploy -Force
```

### Folder structure

| Folder | Purpose |
|---|---|
| `C:\55317BDeploy\WindowsServer2025` | Guest operating system installation media |
| `C:\55317BDeploy\SQLSERVER2025` | SQL Server setup media |
| `C:\55317BDeploy\SSMS22` | SQL Server Management Studio installer |
| `C:\55317BDeploy\VSCode` | Visual Studio Code installer |
| `C:\55317BDeploy\PowerShell7` | PowerShell 7 installer/package |
| `C:\55317BDeploy\NodeJS` | Node.js installer/package |
| `C:\55317BDeploy\Git` | Git installer/package |
| `C:\55317BDeploy\Docker` | Docker installer/package or project resources |
| `C:\55317BDeploy\SampleDatabases` | Sample database backups |
| `C:\55317BDeploy\CourseFiles` | Course class files and lab resources |
| `C:\55317BDeploy\Logs` | Setup and validation logs |
| `C:\55317BDeploy\HyperV\VirtualMachines` | Hyper-V VM configuration files |
| `C:\55317BDeploy\HyperV\VirtualHardDisks` | Hyper-V VHDX files |
| `C:\55317BDeploy\HyperV\Checkpoints` | Hyper-V checkpoints |
| `C:\55317BDeploy\HyperV\Exports` | Hyper-V exports |

You can let the script create missing folders, but placing the downloads before the first run is the smoothest client experience.

## Required setup files

| Required | Resource | Folder | Expected file(s) | Notes |
|---:|---|---|---|---|
| Yes | windows ISO | `C:\55317BDeploy\WindowsServer2025` | `WindowsServer2025.iso`, `*.iso` | Licensed Windows installation ISO supplied by the client. |
| Yes | SQL Server setup media | `C:\55317BDeploy\SQLSERVER2025` | `setup.exe` | Extract SQL Server media so setup.exe is directly available in this folder. SQL Server ISO-only folders are not accepted by the single-script install path. |
| Yes | SSMS 22 installer | `C:\55317BDeploy\SSMS22` | `vs_SSMS.exe`, `SSMS-Setup-ENU.exe`, `*SSMS*.exe` | SSMS 22 currently uses the vs_SSMS.exe Visual Studio Installer bootstrapper. |
| Yes | Visual Studio Code installer | `C:\55317BDeploy\VSCode` | `VSCodeSetup-x64.exe`, `VSCodeUserSetup-x64.exe`, `*VSCode*Setup*x64*.exe`, `*Code*Setup*x64*.exe` | Use the current x64 Windows installer for Windows-based labs. |
| Yes | PowerShell 7 installer | `C:\55317BDeploy\PowerShell7` | `PowerShell-*.msi`, `*.msi` | Use official PowerShell 7 installer media or package source documentation. |
| Yes | Node.js installer | `C:\55317BDeploy\NodeJS` | `node-*.msi`, `*.msi` | Use official Node.js LTS installer media. |
| Optional | Git installer | `C:\55317BDeploy\Git` | `Git-*.exe`, `*.exe` | Required only when course labs use Git locally. |
| Yes | AdventureWorks2025 backup | `C:\55317BDeploy\SampleDatabases` | `AdventureWorks2025.bak` | Required for SQL Server courses that use AdventureWorks OLTP examples. |
| Yes | AdventureWorksDW2025 backup | `C:\55317BDeploy\SampleDatabases` | `AdventureWorksDW2025.bak` | Required for SQL Server courses that use AdventureWorks data warehouse examples. |
| Optional | Course class files zip | `C:\55317BDeploy\CourseFiles` | `55317B_Classfiles.zip`, `*.zip` | Optional class files archive when the course includes downloadable lab resources. |

## Run the setup

Open PowerShell as Administrator and run:

```powershell
Set-Location C:\55317BDeploy
Set-ExecutionPolicy Bypass -Scope Process -Force
.\55317B-Setup.ps1
```

The script validates the folder structure and required resources before performing setup actions.

## Standard lab accounts

| Platform | Account | Password | Privilege |
|---|---|---|---|
| Windows | `Administrator` | `Pa$$w0rdPa$$w0rd` | Built-in local administrator |
| Windows | `Adminz` | `Pa$$w0rdPa$$w0rd` | Local Administrators |
| Windows | `Student` | `Pa$$w0rd` | Local Administrators |
| Linux | `root` | `Pa$$w0rdPa$$w0rd` | root superuser |
| Linux | `adminz` | `Pa$$w0rdPa$$w0rd` | sudo |
| Linux | `student` | `Pa$$w0rd` | sudo |

These are classroom/lab defaults, not production credentials. Change them after setup if the VM or container will persist beyond the class.

## What the script does

The generated script follows this sequence:

1. Creates the deployment folders if they do not already exist.
2. Validates required media and renders a found/missing checklist.
3. Writes JSON and Markdown validation reports to the Logs folder.
4. Validates the selected local setup target.
5. Creates or prepares the selected local environment when supported by the approved setup profile.
6. Configures standard lab accounts where the setup target supports local accounts.
7. Runs supported installer actions only for approved software in the setup profile.
8. Writes setup status and troubleshooting information to the Logs folder.

## Licensing note

This package does not include Windows, SQL Server, SSMS, Visual Studio Code, database backups, or other third-party installation media.

The client is responsible for obtaining, licensing, and placing the required media in the correct folders before running the setup script.

## Troubleshooting

If the script reports missing media, check the folder and filename table above. The most common causes are renamed installers, ISO files left unextracted when setup.exe is expected, or files placed under a different course deployment root.
