# Lab Environment Refresh
# Runs the centrally maintained refresh/repair script.

$ErrorActionPreference = 'Stop'

$RepairScript = 'C:\Classfiles\StartupRepair.ps1'

Clear-Host
Write-Host 'Lab Environment Refresh' -ForegroundColor Cyan
Write-Host ''
Write-Host 'This will reset and repair the lab environment.' -ForegroundColor Yellow
Write-Host 'Save your work before continuing.' -ForegroundColor Yellow
Write-Host ''

$confirmation = Read-Host 'Type YES to continue'

if ($confirmation -cne 'YES') {
    Write-Host ''
    Write-Host 'Refresh cancelled. No changes were made.' -ForegroundColor Yellow
    Start-Sleep -Seconds 3
    exit 0
}

if (-not (Test-Path -LiteralPath $RepairScript -PathType Leaf)) {
    Write-Host ''
    Write-Host 'ERROR: The refresh script was not found:' -ForegroundColor Red
    Write-Host $RepairScript -ForegroundColor Red
    Read-Host 'Press Enter to close'
    exit 1
}

Write-Host ''
Write-Host 'Starting lab refresh. This may take several minutes...' -ForegroundColor Cyan
Write-Host ''

try {
    & $RepairScript

    if ($LASTEXITCODE -and $LASTEXITCODE -ne 0) {
        throw "The repair script returned exit code $LASTEXITCODE."
    }

    Write-Host ''
    Write-Host 'Lab refresh completed successfully.' -ForegroundColor Green
}
catch {
    Write-Host ''
    Write-Host "Lab refresh failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host 'Contact your instructor or support team if the problem continues.' -ForegroundColor Yellow
    Read-Host 'Press Enter to close'
    exit 1
}

Read-Host 'Press Enter to close'