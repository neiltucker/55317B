# ============================================================================== 
# 55317B Local Lab Setup - Windows Server 2025
#
# Purpose
#   Build the current Windows Server 2025 system as a standalone/workgroup
#   classroom server. This version DOES NOT install or configure Active Directory
#   Domain Services and DOES NOT promote the computer to a domain controller.
#
# Requested lab configuration
#   Computer/NetBIOS name:  LAB65000
#   Existing Adminz pwd:    Pa$$w0rdPa$$w0rd
#   Student/Admin1/Admin2/
#   SQLService pwd:         Pa$$w0rd
#   SQL Server media:       C:\SQLServer2025\setup.exe
#   SQL instance:           Default instance (MSSQLSERVER)
#   Authentication:         Mixed Mode
#   sa password:            Pa$$w0rd
#   Class files:            C:\Classfiles
#
# Behavior
#   - Requires a standalone/workgroup server. It will not join, create, demote,
#     or remove a domain.
#   - Relaxes the LOCAL password policy for repeatable classroom exercises.
#   - Creates/normalizes the requested LOCAL accounts.
#   - Renames the computer to LAB65000 when needed and resumes automatically
#     after the one required reboot.
#   - Installs SQL Server 2025 from C:\SQLServer2025\setup.exe as MSSQLSERVER.
#   - Configures Mixed Mode and grants all requested local accounts sysadmin.
#   - Ensures AdventureWorks2025.bak and AdventureWorksDW2025.bak are present in
#     C:\Classfiles, then restores both databases into the default instance.
#   - Optionally installs SSMS 22 and VS Code when their deployment media exist.
# ============================================================================== 
#Requires -RunAsAdministrator
#Requires -Version 5.1

[CmdletBinding()]
param(
    [ValidateSet('Auto','PreRename','PostRename')]
    [string]$Stage = 'Auto'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# ------------------------------------------------------------------------------
# Configuration
# ------------------------------------------------------------------------------
$DesiredComputerName       = 'LAB65000'
$AdminzPasswordPlain       = 'Pa$$w0rdPa$$w0rd'
$LabPasswordPlain          = 'Pa$$w0rd'
$SqlSaPasswordPlain        = 'Pa$$w0rd'

$SqlSetupExe               = 'C:\SQLServer2025\setup.exe'
$Classfiles                = 'C:\Classfiles'
$TempDir                   = 'C:\Temp'
$ContinuationScript        = 'C:\Temp\55317B-LocalSetup.ps1'
$ContinuationTaskName      = '55317B-ContinueSetup'
$TranscriptPath            = 'C:\Temp\55317B-LocalSetup.log'
$SqlIniPath                = 'C:\Temp\55317B-SQLServer.ini'

$AdventureWorksBackupName  = 'AdventureWorks2025.bak'
$AdventureWorksDwBakName   = 'AdventureWorksDW2025.bak'
$AdventureWorksBackup      = Join-Path $Classfiles $AdventureWorksBackupName
$AdventureWorksDwBackup    = Join-Path $Classfiles $AdventureWorksDwBakName

$RequestedAccountPasswords = [ordered]@{
    'Adminz'     = $AdminzPasswordPlain
    'Student'    = $LabPasswordPlain
    'Admin1'     = $LabPasswordPlain
    'Admin2'     = $LabPasswordPlain
    'SQLService' = $LabPasswordPlain
}

# ------------------------------------------------------------------------------
# Utility functions
# ------------------------------------------------------------------------------
function Write-Step {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "`n==> $Message" -ForegroundColor Cyan
}

function Assert-FileExists {
    param(
        [Parameter(Mandatory)][string]$Label,
        [Parameter(Mandatory)][string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Missing $Label at: $Path"
    }
}

function Invoke-NativeChecked {
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter(Mandatory)][string[]]$Arguments,
        [Parameter(Mandatory)][string]$FailureMessage,
        [int[]]$SuccessExitCodes = @(0)
    )

    & $FilePath @Arguments
    $exitCode = $LASTEXITCODE
    if ($exitCode -notin $SuccessExitCodes) {
        throw "$FailureMessage Exit code: $exitCode"
    }
    return $exitCode
}

function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Get-ComputerState {
    Get-CimInstance -ClassName Win32_ComputerSystem
}

function Assert-StandaloneLabServer {
    $computer = Get-ComputerState

    # Win32_ComputerSystem.DomainRole: 4 = Backup DC, 5 = Primary DC.
    if ([int]$computer.DomainRole -in @(4,5)) {
        throw "This computer is currently a domain controller. This standalone version intentionally does not demote domain controllers. Demote/rebuild it first, then rerun this script."
    }

    if ($computer.PartOfDomain) {
        throw "This computer is currently joined to domain '$($computer.Domain)'. This standalone version will not unjoin a domain automatically. Move it to a workgroup first, then rerun this script."
    }

    return $computer
}

function Get-LocalPrincipalName {
    param([Parameter(Mandatory)][string]$UserName)
    return "$env:COMPUTERNAME\$UserName"
}

# ------------------------------------------------------------------------------
# Local account/password policy
# ------------------------------------------------------------------------------
function Set-LocalLabPasswordPolicy {
    Write-Step 'Relaxing LOCAL password policy for the classroom lab'

    # Allow short/reused passwords and immediate repeated resets. Passwords are
    # still explicitly required on each requested account below.
    Invoke-NativeChecked -FilePath "$env:SystemRoot\System32\net.exe" `
        -Arguments @('accounts','/minpwlen:0','/minpwage:0','/maxpwage:unlimited','/uniquepw:0') `
        -FailureMessage 'Failed to update local password policy with NET ACCOUNTS.' | Out-Null

    $policyInf = Join-Path $TempDir '55317B-LocalPasswordPolicy.inf'
    $policyDb  = Join-Path $TempDir '55317B-LocalPasswordPolicy.sdb'

    @'
[Unicode]
Unicode=yes
[Version]
signature="$CHICAGO$"
Revision=1
[System Access]
MinimumPasswordAge = 0
MinimumPasswordLength = 0
PasswordComplexity = 0
PasswordHistorySize = 0
LockoutBadCount = 0
'@ | Set-Content -LiteralPath $policyInf -Encoding Unicode

    Invoke-NativeChecked -FilePath "$env:SystemRoot\System32\secedit.exe" `
        -Arguments @('/configure','/db',$policyDb,'/cfg',$policyInf,'/areas','SECURITYPOLICY','/quiet') `
        -FailureMessage 'Failed to update the local security password policy with SECEDIT.' | Out-Null

    Write-Host 'Local password complexity/history/minimum-age restrictions are disabled for this lab.' -ForegroundColor Green
}

function Ensure-LocalLabAccounts {
    Write-Step 'Creating/normalizing LOCAL lab accounts'

    foreach ($entry in $RequestedAccountPasswords.GetEnumerator()) {
        $name = [string]$entry.Key
        $plainPassword = [string]$entry.Value
        $securePassword = ConvertTo-SecureString $plainPassword -AsPlainText -Force
        $existing = Get-LocalUser -Name $name -ErrorAction SilentlyContinue

        if ($existing) {
            Set-LocalUser -Name $name -Password $securePassword -PasswordNeverExpires $true
            Enable-LocalUser -Name $name -ErrorAction SilentlyContinue
            Write-Host "Local account $name already existed; password/settings normalized."
        }
        else {
            New-LocalUser -Name $name `
                -Password $securePassword `
                -FullName "$name Account" `
                -PasswordNeverExpires | Out-Null
            Write-Host "Created local account $name."
        }

        # Keep weak/reusable lab passwords permitted while still requiring each
        # account to have a password.
        Invoke-NativeChecked -FilePath "$env:SystemRoot\System32\net.exe" `
            -Arguments @('user', $name, '/passwordreq:yes') `
            -FailureMessage "Failed to set PasswordRequired=Yes for local account '$name'." | Out-Null
    }

    # Adminz is the Windows administrative account for this build.
    $adminMembers = @(Get-LocalGroupMember -Group 'Administrators' -ErrorAction Stop)
    if (-not ($adminMembers | Where-Object { $_.Name -ieq "$env:COMPUTERNAME\Adminz" })) {
        Add-LocalGroupMember -Group 'Administrators' -Member 'Adminz'
        Write-Host 'Added local Adminz to Administrators.'
    }
}

# ------------------------------------------------------------------------------
# Deployment media staging
# ------------------------------------------------------------------------------
function Get-FirstExistingFile {
    param([Parameter(Mandatory)][string[]]$Candidates)
    foreach ($candidate in $Candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            return $candidate
        }
    }
    return $null
}

function Stage-ClassFilesAndBackups {
    Write-Step 'Staging course files and AdventureWorks backups in C:\Classfiles'
    Ensure-Directory -Path $Classfiles

    # Preserve any supplied course files from the earlier deployment layout.
    $courseDirs = @(
        (Join-Path $PSScriptRoot 'CourseFiles'),
        'C:\55317BDeploy\CourseFiles'
    ) | Select-Object -Unique

    foreach ($courseDir in $courseDirs) {
        if (Test-Path -LiteralPath $courseDir -PathType Container) {
            $items = @(Get-ChildItem -LiteralPath $courseDir -Force -ErrorAction SilentlyContinue)
            if ($items.Count -gt 0) {
                $items | Copy-Item -Destination $Classfiles -Recurse -Force
                Write-Host "Copied course files from $courseDir."
                break
            }
        }
    }

    $backupMap = [ordered]@{
        $AdventureWorksBackupName = $AdventureWorksBackup
        $AdventureWorksDwBakName  = $AdventureWorksDwBackup
    }

    foreach ($backupName in $backupMap.Keys) {
        $destination = [string]$backupMap[$backupName]

        if (Test-Path -LiteralPath $destination -PathType Leaf) {
            Write-Host "$backupName already exists in C:\Classfiles."
            continue
        }

        $source = Get-FirstExistingFile -Candidates @(
            (Join-Path $PSScriptRoot "SampleDatabases\$backupName"),
            (Join-Path $PSScriptRoot $backupName),
            "C:\55317BDeploy\SampleDatabases\$backupName",
            "C:\SampleDatabases\$backupName",
            "C:\SQLServer2025\SampleDatabases\$backupName"
        )

        if (-not $source) {
            throw "Could not find $backupName. Place it in C:\Classfiles, a SampleDatabases folder beside this script, C:\55317BDeploy\SampleDatabases, or C:\SQLServer2025\SampleDatabases, then rerun the script."
        }

        Copy-Item -LiteralPath $source -Destination $destination -Force
        Write-Host "Copied $backupName to $destination."
    }

    Assert-FileExists -Label 'AdventureWorks2025 backup' -Path $AdventureWorksBackup
    Assert-FileExists -Label 'AdventureWorksDW2025 backup' -Path $AdventureWorksDwBackup
}

function Install-OptionalClientTools {
    # Kept from the original deployment. Missing client-tool media does not
    # block SQL Server or database setup.
    Write-Step 'Checking optional SSMS 22 and VS Code installers'

    $ssmsExe = Get-FirstExistingFile -Candidates @(
        (Join-Path $PSScriptRoot 'SSMS22\vs_SSMS.exe'),
        'C:\55317BDeploy\SSMS22\vs_SSMS.exe'
    )

    $ssmsInstalled = @(
        'C:\Program Files\Microsoft SQL Server Management Studio 22\Common7\IDE\Ssms.exe',
        'C:\Program Files (x86)\Microsoft SQL Server Management Studio 22\Common7\IDE\Ssms.exe'
    ) | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1

    if (-not $ssmsInstalled -and $ssmsExe) {
        Write-Host 'Installing SQL Server Management Studio 22...'
        $proc = Start-Process -FilePath $ssmsExe -ArgumentList @('--passive','--includeRecommended','--norestart','--wait') -Wait -PassThru
        if ($proc.ExitCode -notin @(0,3010)) {
            throw "SSMS installation failed with exit code $($proc.ExitCode)."
        }
    }
    elseif ($ssmsInstalled) {
        Write-Host 'SSMS 22 is already installed.'
    }
    else {
        Write-Host 'SSMS 22 media not found; skipping optional SSMS installation.' -ForegroundColor Yellow
    }

    $vsCodeExe = $null
    $vsCodeDirs = @(
        (Join-Path $PSScriptRoot 'VSCode'),
        'C:\55317BDeploy\VSCode'
    ) | Select-Object -Unique

    foreach ($vsCodeDir in $vsCodeDirs) {
        if (Test-Path -LiteralPath $vsCodeDir -PathType Container) {
            $vsCodeExe = Get-ChildItem -LiteralPath $vsCodeDir -Filter 'vscodesetup*.exe' -File -ErrorAction SilentlyContinue | Select-Object -First 1
            if ($vsCodeExe) { break }
        }
    }

    if (-not (Test-Path -LiteralPath 'C:\Program Files\Microsoft VS Code\Code.exe') -and $vsCodeExe) {
        Write-Host 'Installing Visual Studio Code...'
        $proc = Start-Process -FilePath $vsCodeExe.FullName -ArgumentList @('/VERYSILENT','/SUPPRESSMSGBOXES','/ALLUSERS','/MERGETASKS=!runcode') -Wait -PassThru
        if ($proc.ExitCode -notin @(0,3010)) {
            throw "VS Code installation failed with exit code $($proc.ExitCode)."
        }
    }
    elseif (Test-Path -LiteralPath 'C:\Program Files\Microsoft VS Code\Code.exe') {
        Write-Host 'VS Code is already installed.'
    }
    else {
        Write-Host 'VS Code media not found; skipping optional VS Code installation.' -ForegroundColor Yellow
    }
}

# ------------------------------------------------------------------------------
# Computer rename and automatic continuation
# ------------------------------------------------------------------------------
function Save-And-RegisterContinuation {
    Write-Step 'Preparing automatic continuation after the computer-name reboot'

    if ([string]::IsNullOrWhiteSpace($PSCommandPath)) {
        throw 'Unable to determine this script path; automatic continuation cannot be configured.'
    }

    if ($PSCommandPath -ine $ContinuationScript) {
        Copy-Item -LiteralPath $PSCommandPath -Destination $ContinuationScript -Force
    }

    $powerShellExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $action = New-ScheduledTaskAction `
        -Execute $powerShellExe `
        -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$ContinuationScript`" -Stage PostRename"
    $trigger = New-ScheduledTaskTrigger -AtStartup
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit ([TimeSpan]::Zero)

    Register-ScheduledTask `
        -TaskName $ContinuationTaskName `
        -Action $action `
        -Trigger $trigger `
        -Settings $settings `
        -User 'SYSTEM' `
        -RunLevel Highest `
        -Force | Out-Null

    Write-Host "Registered startup task '$ContinuationTaskName'."
}

function Ensure-ComputerName {
    $computer = Assert-StandaloneLabServer

    if ($computer.Name -ieq $DesiredComputerName) {
        Write-Host "Computer is already named $DesiredComputerName."
        return $false
    }

    Write-Step "Renaming computer from '$($computer.Name)' to '$DesiredComputerName'"
    Save-And-RegisterContinuation
    Rename-Computer -NewName $DesiredComputerName -Force -ErrorAction Stop
    Write-Host "Computer rename queued successfully. A reboot is required." -ForegroundColor Green
    return $true
}

# ------------------------------------------------------------------------------
# SQL Server configuration
# ------------------------------------------------------------------------------
function Get-SqlRegistryPath {
    $instanceMapPath = 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL'
    if (-not (Test-Path -LiteralPath $instanceMapPath)) {
        return $null
    }

    $instanceMap = Get-ItemProperty -LiteralPath $instanceMapPath -ErrorAction Stop
    $instanceId = $instanceMap.MSSQLSERVER
    if ([string]::IsNullOrWhiteSpace([string]$instanceId)) {
        return $null
    }

    return "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$instanceId\MSSQLServer"
}

function Ensure-SqlMixedModeRegistry {
    $registryPath = Get-SqlRegistryPath
    if (-not $registryPath) {
        return
    }

    $loginMode = (Get-ItemProperty -LiteralPath $registryPath -Name 'LoginMode' -ErrorAction Stop).LoginMode
    if ([int]$loginMode -ne 2) {
        Write-Host 'Existing SQL instance is not configured for Mixed Mode; changing LoginMode to 2.' -ForegroundColor Yellow
        Set-ItemProperty -LiteralPath $registryPath -Name 'LoginMode' -Type DWord -Value 2
        Restart-Service -Name 'MSSQLSERVER' -Force
        Start-Sleep -Seconds 5
    }
}

function New-SaConnection {
    $builder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder
    $builder['Data Source'] = 'localhost'
    $builder['Initial Catalog'] = 'master'
    $builder['User ID'] = 'sa'
    $builder['Password'] = $SqlSaPasswordPlain
    $builder['TrustServerCertificate'] = $true
    $builder['Connect Timeout'] = 5
    return [System.Data.SqlClient.SqlConnection]::new($builder.ConnectionString)
}

function New-IntegratedConnection {
    $builder = New-Object System.Data.SqlClient.SqlConnectionStringBuilder
    $builder['Data Source'] = 'localhost'
    $builder['Initial Catalog'] = 'master'
    $builder['Integrated Security'] = $true
    $builder['TrustServerCertificate'] = $true
    $builder['Connect Timeout'] = 5
    return [System.Data.SqlClient.SqlConnection]::new($builder.ConnectionString)
}

function Wait-SqlServer {
    param([int]$TimeoutSeconds = 180)

    $deadline = (Get-Date).AddSeconds($TimeoutSeconds)
    do {
        $service = Get-Service -Name 'MSSQLSERVER' -ErrorAction SilentlyContinue
        if ($service -and $service.Status -eq 'Running') {
            $connection = $null
            try {
                $connection = New-SaConnection
                $connection.Open()
                $connection.Close()
                $connection.Dispose()
                return
            }
            catch {
                if ($connection) { $connection.Dispose() }
            }
        }
        Start-Sleep -Seconds 3
    } while ((Get-Date) -lt $deadline)

    throw "SQL Server did not become ready for sa connections within $TimeoutSeconds seconds."
}

function Grant-SqlBackupReadAccess {
    param([Parameter(Mandatory)][string]$RequestedSqlServiceAccount)

    $identities = New-Object System.Collections.Generic.List[string]
    $identities.Add($RequestedSqlServiceAccount)

    $sqlService = Get-CimInstance Win32_Service -Filter "Name='MSSQLSERVER'" -ErrorAction SilentlyContinue
    if ($sqlService -and -not [string]::IsNullOrWhiteSpace([string]$sqlService.StartName)) {
        if (-not ($identities -contains [string]$sqlService.StartName)) {
            $identities.Add([string]$sqlService.StartName)
        }
    }

    foreach ($identity in $identities) {
        if ($identity -ieq 'LocalSystem') { continue }
        try {
            Invoke-NativeChecked -FilePath "$env:SystemRoot\System32\icacls.exe" `
                -Arguments @($Classfiles,'/grant',"${identity}:(OI)(CI)RX",'/T','/C') `
                -FailureMessage "Failed to grant '$identity' read access to C:\Classfiles." | Out-Null
        }
        catch {
            # Do not mask the requested SQLService ACL failure. For a different
            # pre-existing service identity, report a warning and allow RESTORE
            # to provide the definitive result.
            if ($identity -ieq $RequestedSqlServiceAccount) { throw }
            Write-Warning $_.Exception.Message
        }
    }
}

function Install-SqlServer2025 {
    Assert-FileExists -Label 'SQL Server 2025 setup.exe' -Path $SqlSetupExe

    if ($env:COMPUTERNAME -ine $DesiredComputerName) {
        throw "SQL Server installation requires the computer name to be '$DesiredComputerName'. Current name is '$env:COMPUTERNAME'."
    }

    $sqlServiceAccount = Get-LocalPrincipalName -UserName 'SQLService'
    $sqlSysadmins = @('Adminz','Student','Admin1','Admin2','SQLService') | ForEach-Object {
        Get-LocalPrincipalName -UserName $_
    }

    if (-not (Get-Service -Name 'MSSQLSERVER' -ErrorAction SilentlyContinue)) {
        Write-Step 'Installing SQL Server 2025 default instance in Mixed Mode'

        $sqlSysadminLine = 'SQLSYSADMINACCOUNTS=' + (($sqlSysadmins | ForEach-Object { '"' + $_ + '"' }) -join ' ')

        @(
            '[OPTIONS]'
            'ACTION="Install"'
            'FEATURES=SQLENGINE'
            'INSTANCENAME="MSSQLSERVER"'
            'INSTANCEID="MSSQLSERVER"'
            'SECURITYMODE="SQL"'
            ('SQLSVCACCOUNT="{0}"' -f $sqlServiceAccount)
            'SQLSVCSTARTUPTYPE="Automatic"'
            ('AGTSVCACCOUNT="{0}"' -f $sqlServiceAccount)
            'AGTSVCSTARTUPTYPE="Automatic"'
            $sqlSysadminLine
            'SQLCOLLATION="SQL_Latin1_General_CP1_CI_AS"'
            'TCPENABLED="1"'
            'NPENABLED="0"'
            'BROWSERSVCSTARTUPTYPE="Automatic"'
            'UPDATEENABLED="False"'
            'QUIET="True"'
        ) | Set-Content -LiteralPath $SqlIniPath -Encoding ASCII

        $sqlArgs = @(
            '/Q',
            "/CONFIGURATIONFILE=$SqlIniPath",
            "/SAPWD=$SqlSaPasswordPlain",
            "/SQLSVCPASSWORD=$LabPasswordPlain",
            "/AGTSVCPASSWORD=$LabPasswordPlain",
            '/IACCEPTSQLSERVERLICENSETERMS'
        )

        & $SqlSetupExe @sqlArgs | Out-Host
        $sqlExitCode = $LASTEXITCODE
        if ($sqlExitCode -notin @(0,3010)) {
            throw "SQL Server 2025 Setup failed with exit code $sqlExitCode. Review the SQL Server Setup Bootstrap log under C:\Program Files\Microsoft SQL Server."
        }
        if ($sqlExitCode -eq 3010) {
            Write-Warning 'SQL Server Setup completed successfully but returned 3010 (restart requested). The script will continue with validation.'
        }
    }
    else {
        Write-Host 'Default SQL Server instance already exists; skipping SQL binary installation.' -ForegroundColor Yellow
    }

    $sqlService = Get-Service -Name 'MSSQLSERVER' -ErrorAction Stop
    Set-Service -Name 'MSSQLSERVER' -StartupType Automatic
    if ($sqlService.Status -ne 'Running') {
        Start-Service -Name 'MSSQLSERVER'
    }

    $agent = Get-Service -Name 'SQLSERVERAGENT' -ErrorAction SilentlyContinue
    if ($agent) {
        Set-Service -Name 'SQLSERVERAGENT' -StartupType Automatic
        if ($agent.Status -ne 'Running') {
            try { Start-Service -Name 'SQLSERVERAGENT' } catch { Write-Warning "SQL Server Agent could not be started yet: $($_.Exception.Message)" }
        }
    }

    Ensure-SqlMixedModeRegistry

    # For a pre-existing instance, normalize the sa password when possible.
    $saReady = $false
    $saTest = $null
    try {
        $saTest = New-SaConnection
        $saTest.Open()
        $saReady = $true
        $saTest.Close()
        $saTest.Dispose()
    }
    catch {
        if ($saTest) { $saTest.Dispose() }
    }

    if (-not $saReady) {
        $integrated = $null
        try {
            $integrated = New-IntegratedConnection
            $integrated.Open()
            $escapedSaPassword = $SqlSaPasswordPlain.Replace("'", "''")
            $cmd = $integrated.CreateCommand()
            $cmd.CommandText = "ALTER LOGIN [sa] WITH PASSWORD = N'$escapedSaPassword'; ALTER LOGIN [sa] ENABLE;"
            [void]$cmd.ExecuteNonQuery()
            $integrated.Close()
            $integrated.Dispose()
            $saReady = $true
        }
        catch {
            if ($integrated) { $integrated.Dispose() }
            throw 'SQL Server exists but neither the configured sa credentials nor the current Windows account can administer it. Mixed Mode and the sa password could not be normalized automatically.'
        }
    }

    Wait-SqlServer
    Grant-SqlBackupReadAccess -RequestedSqlServiceAccount $sqlServiceAccount

    return $sqlSysadmins
}

function Restore-DatabaseFromBackup {
    param(
        [Parameter(Mandatory)][System.Data.SqlClient.SqlConnection]$Connection,
        [Parameter(Mandatory)][string]$DatabaseName,
        [Parameter(Mandatory)][string]$BackupPath
    )

    Assert-FileExists -Label "$DatabaseName backup" -Path $BackupPath

    $check = $Connection.CreateCommand()
    $check.CommandText = 'SELECT database_id FROM sys.databases WHERE name = @name;'
    [void]$check.Parameters.Add('@name', [System.Data.SqlDbType]::NVarChar, 128)
    $check.Parameters['@name'].Value = $DatabaseName
    if ($check.ExecuteScalar()) {
        Write-Host "Database $DatabaseName already exists; restore skipped." -ForegroundColor Yellow
        return
    }

    Write-Host "Restoring $DatabaseName from $BackupPath..."
    $escapedBackup = $BackupPath.Replace("'", "''")

    $fileList = $Connection.CreateCommand()
    $fileList.CommandTimeout = 0
    $fileList.CommandText = "RESTORE FILELISTONLY FROM DISK = N'$escapedBackup';"
    $reader = $fileList.ExecuteReader()

    $files = @()
    while ($reader.Read()) {
        $files += [pscustomobject]@{
            LogicalName = [string]$reader['LogicalName']
            Type        = [string]$reader['Type']
        }
    }
    $reader.Close()

    if ($files.Count -eq 0) {
        throw "RESTORE FILELISTONLY returned no files for $BackupPath."
    }

    $pathCommand = $Connection.CreateCommand()
    $pathCommand.CommandText = @"
SELECT
    CAST(SERVERPROPERTY('InstanceDefaultDataPath') AS nvarchar(4000)) AS DataPath,
    CAST(SERVERPROPERTY('InstanceDefaultLogPath') AS nvarchar(4000)) AS LogPath;
"@
    $pathReader = $pathCommand.ExecuteReader()
    if (-not $pathReader.Read()) {
        $pathReader.Close()
        throw 'Unable to determine SQL Server default data/log paths.'
    }
    $dataPath = [string]$pathReader['DataPath']
    $logPath  = [string]$pathReader['LogPath']
    $pathReader.Close()

    if ([string]::IsNullOrWhiteSpace($dataPath) -or [string]::IsNullOrWhiteSpace($logPath)) {
        throw 'SQL Server returned an empty default data or log path.'
    }

    $moveClauses = @()
    $dataIndex = 0
    $logIndex = 0

    foreach ($file in $files) {
        $logical = $file.LogicalName.Replace("'", "''")
        if ($file.Type -eq 'L') {
            $logIndex++
            $suffix = if ($logIndex -eq 1) { '' } else { "_$logIndex" }
            $target = Join-Path $logPath "$DatabaseName$suffix.ldf"
        }
        else {
            $dataIndex++
            $suffix = if ($dataIndex -eq 1) { '' } else { "_$dataIndex" }
            $extension = if ($dataIndex -eq 1) { '.mdf' } else { '.ndf' }
            $target = Join-Path $dataPath "$DatabaseName$suffix$extension"
        }

        $escapedTarget = $target.Replace("'", "''")
        $moveClauses += "MOVE N'$logical' TO N'$escapedTarget'"
    }

    $restore = $Connection.CreateCommand()
    $restore.CommandTimeout = 0
    $restore.CommandText = "RESTORE DATABASE [$DatabaseName] FROM DISK = N'$escapedBackup' WITH $($moveClauses -join ', '), REPLACE, RECOVERY;"
    [void]$restore.ExecuteNonQuery()

    Write-Host "$DatabaseName restored successfully." -ForegroundColor Green
}

function Configure-And-ValidateSql {
    param([Parameter(Mandatory)][string[]]$SqlSysadmins)

    Write-Step 'Verifying Mixed Mode and SQL sysadmin memberships'
    $connection = New-SaConnection
    $connection.Open()

    try {
        $modeCmd = $connection.CreateCommand()
        $modeCmd.CommandText = "SELECT CAST(SERVERPROPERTY('IsIntegratedSecurityOnly') AS int);"
        $integratedOnly = [int]$modeCmd.ExecuteScalar()
        if ($integratedOnly -ne 0) {
            throw 'SQL Server reports Windows-only authentication; Mixed Mode validation failed.'
        }

        foreach ($login in $SqlSysadmins) {
            $escapedLogin = $login.Replace(']', ']]')
            $loginLiteral = $login.Replace("'", "''")
            $cmd = $connection.CreateCommand()
            $cmd.CommandText = @"
IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = N'$loginLiteral')
    CREATE LOGIN [$escapedLogin] FROM WINDOWS;
IF IS_SRVROLEMEMBER('sysadmin', N'$loginLiteral') <> 1
    ALTER SERVER ROLE [sysadmin] ADD MEMBER [$escapedLogin];
"@
            [void]$cmd.ExecuteNonQuery()

            $verify = $connection.CreateCommand()
            $verify.CommandText = "SELECT IS_SRVROLEMEMBER('sysadmin', N'$loginLiteral');"
            if ([int]$verify.ExecuteScalar() -ne 1) {
                throw "SQL sysadmin verification failed for $login."
            }
            Write-Host "$login is a SQL Server sysadmin."
        }

        Write-Step 'Restoring AdventureWorks databases from C:\Classfiles'
        Restore-DatabaseFromBackup -Connection $connection -DatabaseName 'AdventureWorks2025' -BackupPath $AdventureWorksBackup
        Restore-DatabaseFromBackup -Connection $connection -DatabaseName 'AdventureWorksDW2025' -BackupPath $AdventureWorksDwBackup

        foreach ($databaseName in @('AdventureWorks2025','AdventureWorksDW2025')) {
            $verifyDb = $connection.CreateCommand()
            $verifyDb.CommandText = 'SELECT state_desc FROM sys.databases WHERE name = @name;'
            [void]$verifyDb.Parameters.Add('@name', [System.Data.SqlDbType]::NVarChar, 128)
            $verifyDb.Parameters['@name'].Value = $databaseName
            $state = [string]$verifyDb.ExecuteScalar()
            if ($state -ne 'ONLINE') {
                throw "$databaseName is not ONLINE after setup. Current state: $state"
            }
            Write-Host "$databaseName is ONLINE."
        }

        $info = $connection.CreateCommand()
        $info.CommandText = "SELECT CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(128)) + N' | ' + CAST(SERVERPROPERTY('Edition') AS nvarchar(256));"
        $sqlInfo = [string]$info.ExecuteScalar()
        Write-Host "SQL Server: $sqlInfo"
    }
    finally {
        $connection.Close()
        $connection.Dispose()
    }

    $sqlService = Get-CimInstance Win32_Service -Filter "Name='MSSQLSERVER'" -ErrorAction SilentlyContinue
    if ($sqlService) {
        Write-Host "SQL Server service account: $($sqlService.StartName)"
    }
}

# ------------------------------------------------------------------------------
# Stage implementations
# ------------------------------------------------------------------------------
function Invoke-PreRenameStage {
    $computer = Assert-StandaloneLabServer

    Write-Step 'Validating standalone lab prerequisites'
    $os = Get-CimInstance -ClassName Win32_OperatingSystem
    Write-Host "Operating system: $($os.Caption)"
    Write-Host "Computer name:    $($computer.Name)"
    Write-Host "Workgroup:        $($computer.Domain)"
    Write-Host "Current user:     $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"

    Assert-FileExists -Label 'SQL Server 2025 setup.exe' -Path $SqlSetupExe

    Set-LocalLabPasswordPolicy
    Ensure-LocalLabAccounts
    Stage-ClassFilesAndBackups
    Install-OptionalClientTools

    $renameQueued = Ensure-ComputerName
    if (-not $renameQueued) {
        Invoke-PostRenameStage
    }

    return $renameQueued
}

function Invoke-PostRenameStage {
    $computer = Assert-StandaloneLabServer

    if ($computer.Name -ine $DesiredComputerName) {
        throw "Expected computer name '$DesiredComputerName' after restart, but the current name is '$($computer.Name)'."
    }

    Write-Step 'Continuing standalone LAB65000 configuration'
    Write-Host "Computer name: $($computer.Name)"
    Write-Host "Workgroup:     $($computer.Domain)"

    # Reapply idempotently after the rename so local principal names now use
    # LAB65000\<user> consistently.
    Set-LocalLabPasswordPolicy
    Ensure-LocalLabAccounts
    Stage-ClassFilesAndBackups
    Install-OptionalClientTools

    Assert-FileExists -Label 'AdventureWorks2025 backup in C:\Classfiles' -Path $AdventureWorksBackup
    Assert-FileExists -Label 'AdventureWorksDW2025 backup in C:\Classfiles' -Path $AdventureWorksDwBackup

    $sqlSysadmins = Install-SqlServer2025
    Configure-And-ValidateSql -SqlSysadmins $sqlSysadmins

    # Remove any continuation task only after the complete build validates.
    if (Get-ScheduledTask -TaskName $ContinuationTaskName -ErrorAction SilentlyContinue) {
        Unregister-ScheduledTask -TaskName $ContinuationTaskName -Confirm:$false
    }

    Write-Host "`n==============================================================" -ForegroundColor Green
    Write-Host ' 55317B LOCAL LAB SETUP COMPLETE' -ForegroundColor Green
    Write-Host '==============================================================' -ForegroundColor Green
    Write-Host "Computer name:       $env:COMPUTERNAME"
    Write-Host 'Directory mode:      Standalone/workgroup (NO Active Directory)'
    Write-Host 'Windows administrator: LAB65000\Adminz'
    Write-Host 'SQL instance:        MSSQLSERVER (default instance)'
    Write-Host 'SQL authentication:  Mixed Mode'
    Write-Host 'SQL sysadmins:       Adminz, Student, Admin1, Admin2, SQLService'
    Write-Host "Class files:         $Classfiles"
    Write-Host 'Databases:           AdventureWorks2025, AdventureWorksDW2025'
    Write-Host "Transcript:          $TranscriptPath"
}

# ------------------------------------------------------------------------------
# Main
# ------------------------------------------------------------------------------
Ensure-Directory -Path $TempDir
Ensure-Directory -Path $Classfiles

$restartAfterStage = $false
Start-Transcript -Path $TranscriptPath -Append | Out-Null

try {
    $computer = Assert-StandaloneLabServer
    $effectiveStage = $Stage

    if ($effectiveStage -eq 'Auto') {
        if ($computer.Name -ieq $DesiredComputerName) {
            $effectiveStage = 'PostRename'
        }
        else {
            $effectiveStage = 'PreRename'
        }
    }

    Write-Host "55317B setup stage: $effectiveStage"

    switch ($effectiveStage) {
        'PreRename' {
            $restartAfterStage = [bool](Invoke-PreRenameStage)
        }
        'PostRename' {
            Invoke-PostRenameStage
        }
    }
}
catch {
    Write-Host "`n[FATAL ERROR] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Review the transcript at: $TranscriptPath" -ForegroundColor Yellow
    throw
}
finally {
    try { Stop-Transcript | Out-Null } catch { }
}

if ($restartAfterStage) {
    Write-Host "`nComputer rename to $DesiredComputerName is ready. Restarting now; setup will continue automatically after reboot." -ForegroundColor Green
    Restart-Computer -Force
}
