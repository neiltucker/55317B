# ==============================================================================
# 55317B Startup Repair - Disposable/User-Pool Windows Server Machines
# v5.5: Update script to assign admin / sysadmin privileges to appropriate accounts in Windows and SQL Server
#
# Reapplies the local lab state that can be lost when a user-pool machine is
# reset or replaced:
#   - relaxed local password policy
#   - local lab accounts/passwords
#   - Adminz membership in local Administrators
#   - Log on as a service right for SQLService
#   - PSGallery registered and marked Trusted
#   - SqlServer PowerShell module installed for all users
#   - SQL Server sysadmin mappings repaired for the lab accounts
#   - Adminz, Student, Admin1, Admin2, and SQLService are ensured in local Administrators
#   - NT AUTHORITY\INTERACTIVE is also attempted for pooled PhotonUser sessions
#   - PhotonUser and ImageBuilderAdmin are added directly to local Administrators when present
#   - BUILTIN\Administrators, Adminz, Student, Admin1, Admin2, and SQLService
#     are ensured as SQL Server logins and verified as sysadmins
#   - PhotonUser and ImageBuilderAdmin are also given explicit SQL sysadmin logins when present
#
# Optional:
#   Run once with -InstallStartupTask to copy this script to C:\ProgramData\55317B
#   and register it as a SYSTEM startup task.
#
# NOTE:
#   If the pool completely reimages/replaces the VM, a locally registered task
#   will also be lost. In that case, configure the pool/template/provisioning
#   system itself to execute this script on each newly created VM.
# ==============================================================================
#Requires -RunAsAdministrator
#Requires -Version 5.1

[CmdletBinding()]
param(
    [switch]$InstallStartupTask,

    # SQL Server service name. Default instance = MSSQLSERVER.
    # For a named instance use e.g. 'MSSQL$SQL2019'.
    [string]$SqlServiceName = 'MSSQLSERVER',

    # Retained for command-line compatibility with v5.1. v5.2 performs the SQL
    # repair through the known mixed-mode sa account, so single-user recovery
    # is no longer used during the normal repair path.
    [switch]$NoSingleUserRecovery
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# Resolve the name of the computer executing this script. Use this value for
# all machine-qualified local-account references.
$ComputerName = $env:COMPUTERNAME

$LabPasswordPlain    = 'Pa$$w0rd'
$AdminzPasswordPlain = 'Pa$$w0rdPa$$w0rd'
# SINGLE QUOTES ARE INTENTIONAL: preserve both literal $ characters in Pa$$w0rd.
$SqlSaPasswordPlain  = 'Pa$$w0rd'

$RootDir        = 'C:\ProgramData\55317B'
$InstalledScript = Join-Path $RootDir '55317B-StartupRepair.ps1'
$LogPath        = Join-Path $RootDir '55317B-StartupRepair.log'
$TaskName       = '55317B-StartupRepair'

$RequestedAccountPasswords = [ordered]@{
    'Adminz'     = $AdminzPasswordPlain
    'Student'    = $LabPasswordPlain
    'Admin1'     = $LabPasswordPlain
    'Admin2'     = $LabPasswordPlain
    'SQLService' = $LabPasswordPlain
}

$RequiredLabUsers = @(
    'Adminz',
    'Student',
    'Admin1',
    'Admin2',
    'SQLService'
)

$SqlSysadminUsers = $RequiredLabUsers

if ($SqlServiceName -ieq 'MSSQLSERVER') {
    $SqlDataSource       = 'localhost'
    $SqlAgentServiceName = 'SQLSERVERAGENT'
}
else {
    $instanceName        = $SqlServiceName -replace '^MSSQL\$', ''
    $SqlDataSource       = "localhost\$instanceName"
    $SqlAgentServiceName = "SQLAgent`$$instanceName"
}

function Write-Step {
    param([Parameter(Mandatory)][string]$Message)
    Write-Host "`n==> $Message" -ForegroundColor Cyan
}

function Invoke-NativeChecked {
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter(Mandatory)][string[]]$Arguments,
        [Parameter(Mandatory)][string]$FailureMessage,
        [int[]]$SuccessExitCodes = @(0)
    )

    & $FilePath @Arguments | Out-Host
    $exitCode = $LASTEXITCODE
    if ($exitCode -notin $SuccessExitCodes) {
        throw "$FailureMessage Exit code: $exitCode"
    }
}

function Ensure-Directory {
    param([Parameter(Mandatory)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Install-StartupTask {
    Write-Step 'Installing persistent startup repair task'

    if ([string]::IsNullOrWhiteSpace($PSCommandPath)) {
        throw 'Unable to determine the current script path.'
    }

    Ensure-Directory -Path $RootDir

    if ($PSCommandPath -ine $InstalledScript) {
        Copy-Item -LiteralPath $PSCommandPath -Destination $InstalledScript -Force
    }

    $powerShellExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $action = New-ScheduledTaskAction `
        -Execute $powerShellExe `
        -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$InstalledScript`""

    # Run both at Windows startup and at user logon. The logon trigger is
    # important for pooled machines because PhotonUser may not exist yet when
    # the startup trigger runs.
    $startupTrigger = New-ScheduledTaskTrigger -AtStartup
    $logonTrigger   = New-ScheduledTaskTrigger -AtLogOn
    $triggers       = @($startupTrigger, $logonTrigger)

    $settings = New-ScheduledTaskSettingsSet `
        -StartWhenAvailable `
        -ExecutionTimeLimit ([TimeSpan]::Zero) `
        -MultipleInstances IgnoreNew

    Register-ScheduledTask `
        -TaskName $TaskName `
        -Action $action `
        -Trigger $triggers `
        -Settings $settings `
        -User 'SYSTEM' `
        -RunLevel Highest `
        -Force | Out-Null

    Write-Host "Registered startup/logon task '$TaskName'." -ForegroundColor Green
}

function Set-LocalLabPasswordPolicy {
    Write-Step 'Reapplying local classroom password policy'

    Invoke-NativeChecked `
        -FilePath "$env:SystemRoot\System32\net.exe" `
        -Arguments @(
            'accounts',
            '/minpwlen:0',
            '/minpwage:0',
            '/maxpwage:unlimited',
            '/uniquepw:0'
        ) `
        -FailureMessage 'NET ACCOUNTS failed.'

    $policyInf = Join-Path $RootDir '55317B-LocalPasswordPolicy.inf'
    $policyDb  = Join-Path $RootDir '55317B-LocalPasswordPolicy.sdb'

    @'
[Unicode]
Unicode=yes
[Version]
signature="$CHICAGO$"
Revision=1
[System Access]
MinimumPasswordAge = 0
MinimumPasswordLength = 0
PasswordComplexity = 0
PasswordHistorySize = 0
LockoutBadCount = 0
'@ | Set-Content -LiteralPath $policyInf -Encoding Unicode

    Invoke-NativeChecked `
        -FilePath "$env:SystemRoot\System32\secedit.exe" `
        -Arguments @(
            '/configure',
            '/db', $policyDb,
            '/cfg', $policyInf,
            '/areas', 'SECURITYPOLICY',
            '/quiet'
        ) `
        -FailureMessage 'SECEDIT failed while applying the local password policy.'

    Write-Host 'Local lab password policy reapplied.' -ForegroundColor Green
}

function Ensure-LocalLabAccounts {
    Write-Step 'Recreating/normalizing local lab accounts and Administrators membership'

    foreach ($entry in $RequestedAccountPasswords.GetEnumerator()) {
        $name = [string]$entry.Key
        $plainPassword = [string]$entry.Value
        $securePassword = ConvertTo-SecureString $plainPassword -AsPlainText -Force
        $existing = Get-LocalUser -Name $name -ErrorAction SilentlyContinue

        if ($existing) {
            Set-LocalUser `
                -Name $name `
                -Password $securePassword `
                -PasswordNeverExpires $true `
                -ErrorAction Stop

            Enable-LocalUser -Name $name -ErrorAction SilentlyContinue
            Write-Host "Normalized local account $name."
        }
        else {
            New-LocalUser `
                -Name $name `
                -Password $securePassword `
                -FullName "$name Account" `
                -PasswordNeverExpires `
                -ErrorAction Stop | Out-Null

            Write-Host "Created local account $name."
        }

        Invoke-NativeChecked `
            -FilePath "$env:SystemRoot\System32\net.exe" `
            -Arguments @('user', $name, '/passwordreq:yes') `
            -FailureMessage "Failed to require a password for '$name'."
    }

    # Resolve the built-in Administrators group by its well-known SID.
    $administratorsSid = [System.Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
    $administratorsGroup = Get-LocalGroup -SID $administratorsSid -ErrorAction Stop

    function Test-LocalAdministratorSid {
        param([Parameter(Mandatory)][string]$SidValue)

        return [bool](
            Get-LocalGroupMember `
                -Group $administratorsGroup.Name `
                -ErrorAction Stop |
            Where-Object {
                $_.SID -and $_.SID.Value -eq $SidValue
            }
        )
    }

    $adminFailures = New-Object System.Collections.Generic.List[string]

    # REQUIRED: every named lab account must be a direct member of the local
    # built-in Administrators group.
    foreach ($userName in $RequiredLabUsers) {
        try {
            $localUser = Get-LocalUser -Name $userName -ErrorAction Stop

            if (-not (Test-LocalAdministratorSid -SidValue $localUser.SID.Value)) {
                Add-LocalGroupMember `
                    -Group $administratorsGroup.Name `
                    -Member $localUser `
                    -ErrorAction Stop
            }

            if (-not (Test-LocalAdministratorSid -SidValue $localUser.SID.Value)) {
                throw "Membership verification failed."
            }

            Write-Host "VERIFIED WINDOWS ADMIN: $ComputerName\$userName" -ForegroundColor Green
        }
        catch {
            $message = "$ComputerName\$userName : $($_.Exception.Message)"
            $adminFailures.Add($message)
            Write-Host "FAILED WINDOWS ADMIN: $message" -ForegroundColor Red
        }
    }

    # Supplemental AWS pooled-session rule. Failure here must NOT prevent the
    # required named accounts or SQL repair from running.
    try {
        $interactiveSid = 'S-1-5-4'

        if (-not (Test-LocalAdministratorSid -SidValue $interactiveSid)) {
            Add-LocalGroupMember `
                -Group $administratorsGroup.Name `
                -Member 'NT AUTHORITY\INTERACTIVE' `
                -ErrorAction Stop
        }

        if (Test-LocalAdministratorSid -SidValue $interactiveSid) {
            Write-Host 'VERIFIED WINDOWS ADMIN: NT AUTHORITY\INTERACTIVE' -ForegroundColor Green
        }
        else {
            Write-Warning 'NT AUTHORITY\INTERACTIVE could not be verified in local Administrators.'
        }
    }
    catch {
        Write-Warning "Could not add NT AUTHORITY\INTERACTIVE to local Administrators: $($_.Exception.Message)"
    }

    # PhotonUser and ImageBuilderAdmin are dynamic in the pool. Add either directly whenever it exists.
    foreach ($dynamicUserName in @('PhotonUser', 'ImageBuilderAdmin')) {
        try {
            $dynamicUser = Get-LocalUser -Name $dynamicUserName -ErrorAction SilentlyContinue

            if ($dynamicUser) {
                if (-not (Test-LocalAdministratorSid -SidValue $dynamicUser.SID.Value)) {
                    Add-LocalGroupMember `
                        -Group $administratorsGroup.Name `
                        -Member $dynamicUser `
                        -ErrorAction Stop
                }

                if (-not (Test-LocalAdministratorSid -SidValue $dynamicUser.SID.Value)) {
                    throw 'Membership verification failed.'
                }

                Write-Host "VERIFIED WINDOWS ADMIN: $ComputerName\$dynamicUserName" -ForegroundColor Green
            }
            else {
                Write-Host "$dynamicUserName does not exist yet; direct membership deferred until a logon-triggered run." -ForegroundColor Yellow
            }
        }
        catch {
            Write-Warning "$dynamicUserName local Administrators membership failed: $($_.Exception.Message)"
        }
    }

    if ($adminFailures.Count -gt 0) {
        throw "One or more REQUIRED local Administrators memberships failed:`n - $($adminFailures -join "`n - ")"
    }
}

function Ensure-LogOnAsServiceRight {
    param(
        [Parameter(Mandatory)][string]$AccountName
    )

    Write-Step "Ensuring '$AccountName' has Log on as a service"

    $ntAccount = [System.Security.Principal.NTAccount]::new($AccountName)
    $sid = $ntAccount.Translate(
        [System.Security.Principal.SecurityIdentifier]
    ).Value

    $exportInf = Join-Path $RootDir '55317B-UserRights-Export.inf'
    $applyInf  = Join-Path $RootDir '55317B-UserRights-Apply.inf'
    $policyDb  = Join-Path $RootDir '55317B-UserRights.sdb'

    Invoke-NativeChecked `
        -FilePath "$env:SystemRoot\System32\secedit.exe" `
        -Arguments @('/export', '/cfg', $exportInf, '/areas', 'USER_RIGHTS', '/quiet') `
        -FailureMessage 'Unable to export current user-rights policy.'

    $lines = @(Get-Content -LiteralPath $exportInf -Encoding Unicode)
    $rightLineIndex = -1

    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '^\s*SeServiceLogonRight\s*=') {
            $rightLineIndex = $i
            break
        }
    }

    $sidToken = "*$sid"

    if ($rightLineIndex -ge 0) {
        $parts = $lines[$rightLineIndex] -split '=', 2
        $existingValues = @()

        if ($parts.Count -eq 2 -and -not [string]::IsNullOrWhiteSpace($parts[1])) {
            $existingValues = @(
                $parts[1].Split(',') |
                ForEach-Object { $_.Trim() } |
                Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
            )
        }

        if ($existingValues -notcontains $sidToken) {
            $existingValues += $sidToken
            $lines[$rightLineIndex] = 'SeServiceLogonRight = ' + ($existingValues -join ',')
        }
    }
    else {
        $privilegeHeaderIndex = [Array]::IndexOf($lines, '[Privilege Rights]')

        if ($privilegeHeaderIndex -lt 0) {
            $lines += ''
            $lines += '[Privilege Rights]'
            $lines += "SeServiceLogonRight = $sidToken"
        }
        else {
            $before = @()
            $after = @()

            if ($privilegeHeaderIndex -ge 0) {
                $before = @($lines[0..$privilegeHeaderIndex])
            }

            if (($privilegeHeaderIndex + 1) -lt $lines.Count) {
                $after = @($lines[($privilegeHeaderIndex + 1)..($lines.Count - 1)])
            }

            $lines = @($before + "SeServiceLogonRight = $sidToken" + $after)
        }
    }

    $lines | Set-Content -LiteralPath $applyInf -Encoding Unicode

    Invoke-NativeChecked `
        -FilePath "$env:SystemRoot\System32\secedit.exe" `
        -Arguments @(
            '/configure',
            '/db', $policyDb,
            '/cfg', $applyInf,
            '/areas', 'USER_RIGHTS',
            '/quiet'
        ) `
        -FailureMessage "Unable to grant Log on as a service to '$AccountName'."

    Write-Host "'$AccountName' has Log on as a service." -ForegroundColor Green
}

function Ensure-PowerShellGalleryAndSqlServerModule {
    Write-Step 'Configuring PSGallery and SqlServer PowerShell module (v22+)'

    # Windows PowerShell 5.1 may otherwise negotiate an obsolete TLS version.
    [Net.ServicePointManager]::SecurityProtocol = `
        [Net.ServicePointManager]::SecurityProtocol -bor `
        [Net.SecurityProtocolType]::Tls12

    $repo = Get-PSRepository -Name 'PSGallery' -ErrorAction SilentlyContinue
    if (-not $repo) {
        Register-PSRepository -Default
        $repo = Get-PSRepository -Name 'PSGallery' -ErrorAction Stop
    }

    if ($repo.InstallationPolicy -ne 'Trusted') {
        Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
        Write-Host 'PSGallery marked Trusted.'
    }
    else {
        Write-Host 'PSGallery is already Trusted.'
    }

    $nuget = Get-PackageProvider -Name 'NuGet' -ListAvailable -ErrorAction SilentlyContinue |
        Sort-Object Version -Descending |
        Select-Object -First 1

    if (-not $nuget) {
        Install-PackageProvider `
            -Name 'NuGet' `
            -MinimumVersion '2.8.5.201' `
            -Force `
            -ForceBootstrap | Out-Null
    }

    $latestInstalled = Get-Module -ListAvailable -Name 'SqlServer' |
        Sort-Object Version -Descending |
        Select-Object -First 1

    $needInstallOrUpgrade = (
        (-not $latestInstalled) -or
        ($latestInstalled.Version.Major -lt 22)
    )

    if ($needInstallOrUpgrade) {
        $installed = $false
        $lastError = $null

        for ($attempt = 1; $attempt -le 4 -and -not $installed; $attempt++) {
            try {
                Install-Module `
                    -Name 'SqlServer' `
                    -Repository 'PSGallery' `
                    -Scope AllUsers `
                    -MinimumVersion '22.0.0' `
                    -Force `
                    -AllowClobber `
                    -Confirm:$false `
                    -ErrorAction Stop

                $installed = $true
            }
            catch {
                $lastError = $_
                if ($attempt -lt 4) {
                    Start-Sleep -Seconds 20
                }
            }
        }

        if (-not $installed) {
            throw "SqlServer module v22+ installation failed after 4 attempts. $($lastError.Exception.Message)"
        }
    }

    Import-Module SqlServer -MinimumVersion '22.0.0' -Force -ErrorAction Stop

    $version = (Get-Module SqlServer |
        Sort-Object Version -Descending |
        Select-Object -First 1).Version

    if ($version.Major -lt 22) {
        throw "SqlServer module v22+ is required, but version $version was loaded."
    }

    Write-Host "VERIFIED: SqlServer module v$version is loaded." -ForegroundColor Green
}

# ------------------------------------------------------------------------------
# SQL Server repair (v5.4 - SQL Authentication through sa)
# ------------------------------------------------------------------------------

function Get-SidHex {
    param(
        [Parameter(Mandatory)]
        [System.Security.Principal.SecurityIdentifier]$Sid
    )

    $bytes = New-Object byte[] $Sid.BinaryLength
    $Sid.GetBinaryForm($bytes, 0)

    $builder = New-Object System.Text.StringBuilder
    [void]$builder.Append('0x')
    foreach ($b in $bytes) {
        [void]$builder.Append($b.ToString('X2'))
    }

    return $builder.ToString()
}

function ConvertTo-SqlUnicodeLiteral {
    param([Parameter(Mandatory)][string]$Value)

    # This returns the contents for an N'...' T-SQL string literal.
    return $Value.Replace("'", "''")
}

function Invoke-SaSqlcmd {
    param(
        [Parameter(Mandatory)][string]$Query,
        [int]$QueryTimeout = 120
    )

    # SQL repair intentionally uses SQL Authentication. This avoids depending
    # on the identity running the startup task and uses the known mixed-mode
    # sa account supplied for this lab image.
    $invokeParams = @{
        ServerInstance = $SqlDataSource
        Database       = 'master'
        Username       = 'sa'
        Password       = $SqlSaPasswordPlain
        Query          = $Query
        QueryTimeout   = $QueryTimeout
        ErrorAction    = 'Stop'
    }

    # Ensure Invoke-Sqlcmd is available even if the earlier module step loaded
    # it in a different scope. v5.2 intentionally depends on SqlServer v22+.
    $invokeCommand = Get-Command Invoke-Sqlcmd -ErrorAction SilentlyContinue
    if (-not $invokeCommand) {
        Import-Module SqlServer -MinimumVersion '22.0.0' -Force -ErrorAction Stop
        $invokeCommand = Get-Command Invoke-Sqlcmd -ErrorAction Stop
    }

    # SqlServer module v22+ supports this switch. It is important for local
    # lab instances that use SQL Server's self-signed certificate.
    if ($invokeCommand.Parameters.ContainsKey('TrustServerCertificate')) {
        $invokeParams['TrustServerCertificate'] = $true
    }

    return Invoke-Sqlcmd @invokeParams
}

function Test-SaSqlConnection {
    Write-Host "Testing SQL Authentication to '$SqlDataSource' as sa..."

    $result = Invoke-SaSqlcmd -Query @'
SET NOCOUNT ON;
SELECT
    ORIGINAL_LOGIN() AS LoginName,
    CAST(ISNULL(IS_SRVROLEMEMBER(N'sysadmin'), 0) AS int) AS IsSysadmin;
'@

    $row = @($result) | Select-Object -First 1
    if ($null -eq $row) {
        throw 'The sa connection returned no verification row.'
    }

    if ([int]$row.IsSysadmin -ne 1) {
        throw "SQL Authentication succeeded as '$($row.LoginName)', but that login is not sysadmin."
    }

    Write-Host "VERIFIED SQL CONNECTION: $($row.LoginName) is sysadmin." -ForegroundColor Green
}

function Get-SqlSysadminTargets {
    # IMPORTANT: The built-in local Administrators group is a BUILTIN Windows
    # principal. It is NOT COMPUTERNAME\Administrators.
    #
    # Use native PowerShell arrays here rather than New-Object List[object].
    # Windows PowerShell can throw "Argument types do not match" when a
    # New-Object List[object] is later wrapped in @(...).
    $targets = @()
    $missing = @()

    $builtinAdministratorsSid = [System.Security.Principal.SecurityIdentifier]::new('S-1-5-32-544')
    $targets += [pscustomobject]@{
        Name     = 'BUILTIN\Administrators'
        Sid      = $builtinAdministratorsSid
        Required = $true
    }

    foreach ($userName in $SqlSysadminUsers) {
        try {
            $localUser = Get-LocalUser -Name $userName -ErrorAction Stop
            $targets += [pscustomobject]@{
                Name     = "$ComputerName\$userName"
                Sid      = $localUser.SID
                Required = $true
            }
        }
        catch {
            $missing += "$ComputerName\$userName : local account not found ($($_.Exception.Message))"
        }
    }

    foreach ($dynamicUserName in @('PhotonUser', 'ImageBuilderAdmin')) {
        $dynamicUser = Get-LocalUser -Name $dynamicUserName -ErrorAction SilentlyContinue
        if ($dynamicUser) {
            $targets += [pscustomobject]@{
                Name     = "$ComputerName\$dynamicUserName"
                Sid      = $dynamicUser.SID
                Required = $false
            }
        }
        else {
            Write-Host "$dynamicUserName does not exist yet; explicit $dynamicUserName SQL login deferred." -ForegroundColor Yellow
        }
    }

    return [pscustomobject]@{
        Targets = $targets
        Missing = $missing
    }
}

function Ensure-SqlWindowsLoginWithSa {
    param(
        [Parameter(Mandatory)][string]$Principal,
        [Parameter(Mandatory)][System.Security.Principal.SecurityIdentifier]$ExpectedSid
    )

    Write-Host "Ensuring SQL Windows login through sa: $Principal ($($ExpectedSid.Value))"

    $nameLiteral = ConvertTo-SqlUnicodeLiteral -Value $Principal
    $sidHex      = Get-SidHex -Sid $ExpectedSid

    # The SID checks matter on pooled/reimaged machines. A login can have the
    # expected name but a SID from an older machine image; in that case it can
    # never authenticate as the current local Windows account. Conversely, the
    # current SID may already exist under an old computer name after a rename.
    #
    # v5.4 deliberately does ONLY login repair in this batch. Direct sysadmin
    # membership is applied afterward in a separate, uniform ALTER SERVER ROLE
    # pass for BUILTIN\Administrators and every individual local account.
    $query = @"
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @Name         sysname       = N'$nameLiteral';
DECLARE @ExpectedSid  varbinary(85) = $sidHex;
DECLARE @ExistingName sysname;
DECLARE @ExistingSid  varbinary(85);
DECLARE @Sql          nvarchar(max);
DECLARE @DbName       sysname;
DECLARE @JobId        uniqueidentifier;

-- If the desired name exists with a stale SID, remove that stale login first.
SELECT
    @ExistingName = name,
    @ExistingSid  = sid
FROM sys.server_principals
WHERE name = @Name
  AND type IN ('U', 'G');

IF @ExistingName IS NOT NULL AND @ExistingSid <> @ExpectedSid
BEGIN
    -- DROP LOGIN is blocked when the login owns a database or SQL Agent job.
    -- Reassign those common ownerships to sa before dropping the stale login.
    DECLARE db_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT name
        FROM sys.databases
        WHERE owner_sid = @ExistingSid;

    OPEN db_cursor;
    FETCH NEXT FROM db_cursor INTO @DbName;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @Sql = N'ALTER AUTHORIZATION ON DATABASE::' + QUOTENAME(@DbName) + N' TO [sa];';
        EXEC sys.sp_executesql @Sql;
        FETCH NEXT FROM db_cursor INTO @DbName;
    END;
    CLOSE db_cursor;
    DEALLOCATE db_cursor;

    DECLARE job_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT job_id
        FROM msdb.dbo.sysjobs
        WHERE owner_sid = @ExistingSid;

    OPEN job_cursor;
    FETCH NEXT FROM job_cursor INTO @JobId;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC msdb.dbo.sp_update_job
            @job_id = @JobId,
            @owner_login_name = N'sa';
        FETCH NEXT FROM job_cursor INTO @JobId;
    END;
    CLOSE job_cursor;
    DEALLOCATE job_cursor;

    SET @Sql = N'DROP LOGIN ' + QUOTENAME(@Name) + N';';
    EXEC sys.sp_executesql @Sql;
END;

-- If the current Windows SID already exists under an old name, rename that
-- login rather than attempting to create a duplicate SID mapping.
SET @ExistingName = NULL;
SELECT TOP (1) @ExistingName = name
FROM sys.server_principals
WHERE sid = @ExpectedSid
  AND type IN ('U', 'G')
  AND name <> @Name;

IF @ExistingName IS NOT NULL
BEGIN
    SET @Sql = N'ALTER LOGIN ' + QUOTENAME(@ExistingName) +
               N' WITH NAME = ' + QUOTENAME(@Name) + N';';
    EXEC sys.sp_executesql @Sql;
END;

-- Create the current Windows principal when it is not already present.
IF NOT EXISTS
(
    SELECT 1
    FROM sys.server_principals
    WHERE name = @Name
      AND sid = @ExpectedSid
      AND type IN ('U', 'G')
)
BEGIN
    SET @Sql = N'CREATE LOGIN ' + QUOTENAME(@Name) +
               N' FROM WINDOWS WITH DEFAULT_DATABASE = [master];';
    EXEC sys.sp_executesql @Sql;
END;

-- Ensure the login is enabled.
IF EXISTS
(
    SELECT 1
    FROM sys.server_principals
    WHERE name = @Name
      AND sid = @ExpectedSid
      AND type IN ('U', 'G')
      AND is_disabled = 1
)
BEGIN
    SET @Sql = N'ALTER LOGIN ' + QUOTENAME(@Name) + N' ENABLE;';
    EXEC sys.sp_executesql @Sql;
END;

-- Return an authoritative login verification row to PowerShell.
SELECT
    @Name AS PrincipalName,
    CAST(CASE WHEN EXISTS
    (
        SELECT 1
        FROM sys.server_principals
        WHERE name = @Name
          AND sid = @ExpectedSid
          AND type IN ('U', 'G')
    ) THEN 1 ELSE 0 END AS int) AS LoginExists,
    CAST(CASE WHEN EXISTS
    (
        SELECT 1
        FROM sys.server_principals
        WHERE name = @Name
          AND sid = @ExpectedSid
          AND type IN ('U', 'G')
          AND is_disabled = 0
    ) THEN 1 ELSE 0 END AS int) AS LoginEnabled;
"@

    $result = Invoke-SaSqlcmd -Query $query -QueryTimeout 120
    $row = @($result) | Select-Object -Last 1

    if ($null -eq $row) {
        throw "SQL Server returned no login verification row for '$Principal'."
    }

    if ([int]$row.LoginExists -ne 1) {
        throw "Login '$Principal' was not created with the expected Windows SID."
    }

    if ([int]$row.LoginEnabled -ne 1) {
        throw "Login '$Principal' exists but is disabled."
    }

    Write-Host "VERIFIED SQL LOGIN: $Principal" -ForegroundColor Green
}

function Ensure-DirectSqlSysadminMembershipWithSa {
    param(
        [Parameter(Mandatory)][string]$Principal
    )

    # Escape the two contexts independently:
    # - Unicode string literal for catalog lookups
    # - bracketed identifier for ALTER SERVER ROLE
    $nameLiteral = ConvertTo-SqlUnicodeLiteral -Value $Principal
    $principalIdentifier = '[' + $Principal.Replace(']', ']]') + ']'

    Write-Host "Granting direct SQL sysadmin through sa: $Principal"

    # This is intentionally a separate SQL call. Every target, including
    # BUILTIN\Administrators and each MACHINE\User login, uses this exact same
    # ALTER SERVER ROLE statement after the login is known to exist.
    $query = @"
SET NOCOUNT ON;
SET XACT_ABORT ON;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.server_principals
    WHERE name = N'$nameLiteral'
      AND type IN ('U', 'G')
)
BEGIN
    THROW 51000, 'Required Windows login does not exist on the SQL Server instance.', 1;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.server_role_members AS rm
    INNER JOIN sys.server_principals AS r
        ON r.principal_id = rm.role_principal_id
    INNER JOIN sys.server_principals AS m
        ON m.principal_id = rm.member_principal_id
    WHERE r.name = N'sysadmin'
      AND m.name = N'$nameLiteral'
)
BEGIN
    ALTER SERVER ROLE [sysadmin] ADD MEMBER $principalIdentifier;
END;

SELECT
    N'$nameLiteral' AS PrincipalName,
    CAST(CASE WHEN EXISTS
    (
        SELECT 1
        FROM sys.server_role_members AS rm
        INNER JOIN sys.server_principals AS r
            ON r.principal_id = rm.role_principal_id
        INNER JOIN sys.server_principals AS m
            ON m.principal_id = rm.member_principal_id
        WHERE r.name = N'sysadmin'
          AND m.name = N'$nameLiteral'
    ) THEN 1 ELSE 0 END AS int) AS DirectSysadmin;
"@

    $result = Invoke-SaSqlcmd -Query $query -QueryTimeout 120
    $row = @($result) | Select-Object -Last 1

    if ($null -eq $row) {
        throw "SQL Server returned no sysadmin verification row for '$Principal'."
    }

    if ([int]$row.DirectSysadmin -ne 1) {
        throw "Login '$Principal' exists but direct sysadmin membership was not created."
    }

    Write-Host "VERIFIED DIRECT SQL SYSADMIN: $Principal" -ForegroundColor Green
}

function Repair-SqlServerAccess {
    Write-Step "Repairing and verifying REQUIRED SQL Server logins/sysadmin memberships on '$SqlDataSource'"

    if (-not (Get-Service -Name $SqlServiceName -ErrorAction SilentlyContinue)) {
        throw "SQL Server service '$SqlServiceName' is not installed on this machine."
    }

    $service = Get-Service -Name $SqlServiceName -ErrorAction Stop
    if ($service.Status -ne 'Running') {
        Write-Host "SQL Server service '$SqlServiceName' is $($service.Status); starting it..."
        Start-Service -Name $SqlServiceName -ErrorAction Stop
        (Get-Service -Name $SqlServiceName).WaitForStatus(
            [System.ServiceProcess.ServiceControllerStatus]::Running,
            (New-TimeSpan -Seconds 120)
        )
    }

    # Give the Database Engine a short moment to accept client connections after
    # a service start. Then prove the supplied sa account is usable and sysadmin.
    $connected = $false
    $lastError = $null
    for ($attempt = 1; $attempt -le 12 -and -not $connected; $attempt++) {
        try {
            Test-SaSqlConnection
            $connected = $true
        }
        catch {
            $lastError = $_
            if ($attempt -lt 12) {
                Start-Sleep -Seconds 5
            }
        }
    }

    if (-not $connected) {
        throw "Unable to connect to SQL Server '$SqlDataSource' with SQL Authentication as sa. $($lastError.Exception.Message)"
    }

    $targetInfo = Get-SqlSysadminTargets
    $targets = $targetInfo.Targets
    $failures = @()

    Write-Host "Resolved $($targets.Count) SQL login target(s)."

    foreach ($missing in $targetInfo.Missing) {
        $failures += $missing
        Write-Host "FAILED SQL SYSADMIN: $missing" -ForegroundColor Red
    }

    # Phase 1: ensure every Windows principal exists as an enabled SQL login.
    # Keep only successfully repaired logins for the role-assignment phase.
    $readyTargets = @()

    foreach ($target in $targets) {
        try {
            Ensure-SqlWindowsLoginWithSa -Principal $target.Name -ExpectedSid $target.Sid
            $readyTargets += $target
        }
        catch {
            $message = "$($target.Name) : $($_.Exception.Message)"
            if ($target.Required) {
                $failures += $message
                Write-Host "FAILED SQL LOGIN: $message" -ForegroundColor Red
            }
            else {
                Write-Warning "Optional SQL login failed: $message"
            }
        }
    }

    # Phase 2: give EVERY successfully resolved target direct sysadmin membership
    # using the exact same ALTER SERVER ROLE path. Do not rely on inherited
    # BUILTIN\Administrators access or on effective IS_SRVROLEMEMBER results.
    foreach ($target in $readyTargets) {
        try {
            Ensure-DirectSqlSysadminMembershipWithSa -Principal $target.Name
        }
        catch {
            $message = "$($target.Name) : $($_.Exception.Message)"
            if ($target.Required) {
                $failures += $message
                Write-Host "FAILED SQL SYSADMIN: $message" -ForegroundColor Red
            }
            else {
                Write-Warning "Optional SQL sysadmin grant failed: $message"
            }
        }
    }

    if ($failures.Count -gt 0) {
        throw "One or more REQUIRED SQL Server login/sysadmin operations failed:`n - $($failures -join "`n - ")"
    }

    Write-Host 'All REQUIRED SQL Server logins and DIRECT sysadmin memberships verified through the sa connection.' -ForegroundColor Green
}

# ------------------------------------------------------------------------------
# Main
# ------------------------------------------------------------------------------
Ensure-Directory -Path $RootDir

Start-Transcript -Path $LogPath -Append | Out-Null

$overallFailures = New-Object System.Collections.Generic.List[string]

try {
    if ($InstallStartupTask) {
        try {
            Install-StartupTask
        }
        catch {
            $overallFailures.Add("Startup task installation: $($_.Exception.Message)")
            Write-Host "FAILED: startup task installation - $($_.Exception.Message)" -ForegroundColor Red
        }
    }

    try {
        Set-LocalLabPasswordPolicy
    }
    catch {
        $overallFailures.Add("Local password policy: $($_.Exception.Message)")
        Write-Host "FAILED: local password policy - $($_.Exception.Message)" -ForegroundColor Red
    }

    try {
        Ensure-LocalLabAccounts
    }
    catch {
        # Continue to SQL repair so one Windows-group problem does not prevent
        # the remaining required SQL principals from being attempted.
        $overallFailures.Add("Local accounts/Administrators: $($_.Exception.Message)")
        Write-Host "FAILED: local accounts/Administrators - $($_.Exception.Message)" -ForegroundColor Red
    }

    try {
        Ensure-LogOnAsServiceRight -AccountName "$ComputerName\SQLService"
    }
    catch {
        $overallFailures.Add("SQLService Log on as a service: $($_.Exception.Message)")
        Write-Host "FAILED: SQLService Log on as a service - $($_.Exception.Message)" -ForegroundColor Red
    }

    # SqlServer v22+ is required for the lab environment and for the v5.2 SQL
    # repair path, which deliberately uses Invoke-Sqlcmd with SQL Authentication.
    try {
        Ensure-PowerShellGalleryAndSqlServerModule
    }
    catch {
        $overallFailures.Add("PSGallery/SqlServer module: $($_.Exception.Message)")
        Write-Host "FAILED: PSGallery/SqlServer module - $($_.Exception.Message)" -ForegroundColor Red
    }

    try {
        Repair-SqlServerAccess
    }
    catch {
        $overallFailures.Add("SQL Server login/sysadmin repair: $($_.Exception.Message)")
        Write-Host "FAILED: SQL Server login/sysadmin repair - $($_.Exception.Message)" -ForegroundColor Red
    }

    if ($overallFailures.Count -gt 0) {
        throw "55317B startup repair completed with REQUIRED failures:`n - $($overallFailures -join "`n - ")"
    }

    Write-Host "`n55317B startup repair completed successfully." -ForegroundColor Green
    Write-Host "Log: $LogPath"
}
catch {
    Write-Host "`n[FATAL ERROR] $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Review the log at: $LogPath" -ForegroundColor Yellow
    throw
}
finally {
    try {
        Stop-Transcript | Out-Null
    }
    catch {
    }
}
